ZombifyProcess
==============

http://www.malwaretech.com/2014/12/zombie-processes-as-hips-bypass.html
Yes, I use do while(false), please don't hate me. 
